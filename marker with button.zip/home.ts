import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { CardsPage } from '../cards/cards';
import { CordovaFunctionOverride } from '@ionic-native/core';
import { NgZone } from '@angular/core';


declare var google;
let map: any;
let infowindow: any;


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  @ViewChild('mapContainer') mapContainer: ElementRef;
  map: any;

  MyFunction(name) {
    
    this.navCtrl.push(CardsPage, {
      year: name,
    });
  
  }

  constructor(public navCtrl: NavController, public http: Http,public ngZone: NgZone) {
  }


  
  ionViewWillEnter() {
    this.displayGoogleMap();
    this.getMarkers();
    infowindow = new google.maps.InfoWindow({});
  }

  //desplaying the googlemap
  displayGoogleMap() {
    let latLng = new google.maps.LatLng(57.8127004, 14.2106225);
    let mapOptions = {
      center: latLng,
      disableDefaultUI: true,
      zoom: 11,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    this.map = new google.maps.Map(this.mapContainer.nativeElement, mapOptions);
  }




  // fetching custom markers
  getMarkers() {
    this.http.get('assets/data/markers.json')
      .map((res) => res.json())
      .subscribe(data => {
        this.addMarkersToMap(data);
      });
  }





  // showing custom markers
  addMarkersToMap(markers) {
    for (let marker of markers) {
      var position = new google.maps.LatLng(marker.latitude, marker.longitude);
      var dogwalkMarker = new google.maps.Marker({ position: position, title: marker.name });
      dogwalkMarker.setMap(this.map);

      google.maps.event.addListener(dogwalkMarker, 'click', function () {
        console.log('I am in ', dogwalkMarker)
        infowindow.setContent(
          `
          content: <h3>${marker.name}</h3>
          <h5>${marker.address}</h5>
          <button onClick='window.ionicPageRef.zone.run(function (name) { window.ionicPageRef.component.MyFunction(name) })'>My button</button>"
         `);
        infowindow.open(map, this);
      });
    }

    (<any>window).ionicPageRef = {
      zone: this.ngZone,
      component: this
  };
  }
}
